xdata unsigned char LCD_Out _at_ 0xc000;
extern void Delay(unsigned int) reentrant;
unsigned char LCD_Temp;
void LCD_Back_Light(unsigned char On_Off) reentrant
{
	if(On_Off==0)
	{
		LCD_Temp |= 0x40;
	}
	else if(On_Off==1)
	{
		LCD_Temp = (LCD_Temp	|	0x40)	^	0x40;
	}
	LCD_Out   = LCD_Temp;	
}

void LCD_Output_Enable()
{
  	LCD_Temp |= 0x10;
	LCD_Out   = LCD_Temp;
	LCD_Temp ^= 0x10;
	LCD_Out   = LCD_Temp;
	LCD_Temp  = (LCD_Temp	|	0x20)	^	0x20;
	LCD_Out   = LCD_Temp;
} 

void LCD(unsigned char *LCD_Data,unsigned char LCD_Command) reentrant
{
   	unsigned char LCD_Count=0;
   	unsigned char Command = 1;
	LCD_Out=0;
	if(LCD_Data[0] =='�')
	Command = 0;
   	while(LCD_Data[LCD_Count])
	{
		if(Command==1)
		{
			LCD_Temp = ((LCD_Temp	&	0xf0)	|	(LCD_Data[LCD_Count]>>4));
			LCD_Out 	= LCD_Temp;
 			LCD_Temp = LCD_Temp | 0x20;
			LCD_Out 	= LCD_Temp;
		}
		else if(Command==0)
		{
			LCD_Temp = ((LCD_Temp	&	0xf0)	|	(LCD_Command >>4));
			LCD_Out  = LCD_Temp;
			LCD_Temp = (LCD_Temp	|	0x20)	^	0x20;
			LCD_Out  = LCD_Temp;
		}
		LCD_Output_Enable();
		if(Command==1)
		{
			LCD_Temp = (LCD_Temp	&	0xf0)	|	(LCD_Data[LCD_Count]	& 0x0f);
			LCD_Out  = LCD_Temp;
 			LCD_Temp = LCD_Temp | 0x20;
			LCD_Out  = LCD_Temp;
		}
		else if(Command==0)
		{
			LCD_Temp = (LCD_Temp	&	0xf0)	|	(LCD_Command	&	0x0f );
			LCD_Out  = LCD_Temp;
			LCD_Temp = (LCD_Temp	|	0x20)	^	0x20;
			LCD_Out  = LCD_Temp;
		}
		LCD_Output_Enable();
		LCD_Count++;
		if(Command==0)
		Delay(3);  
		Delay(7);  
	}
}
