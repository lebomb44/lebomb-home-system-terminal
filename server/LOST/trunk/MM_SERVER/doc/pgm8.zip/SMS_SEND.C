#include	<reg55.h>
#include	<string.h>

xdata unsigned char TX_Buf[200];
xdata unsigned char Temp[200];
xdata unsigned char SMS_Message[] = "Your Mother My Mother Your Father My Father Your Brother My Brother and Your Wife is EveryBody's ....Hey hope you are enjoying our success!project done!";
xdata unsigned char SMSC_Number[]	= "919841044446";
xdata unsigned char TX_Phone_Number[]	= "9840957045";

bdata unsigned int		  Flag = 0;
sbit TX_Enable		= Flag ^ 0;
sbit RX_Enable		= Flag ^ 1;
sbit SMS_Handling		= Flag ^ 2;		 //0x02
sbit Version			= Flag ^ 3;         //0xd2
sbit Acknowledge		= Flag ^ 4;         //0x7f
sbit Key_Break		= Flag ^ 5;
sbit Key_Enable		= Flag ^ 6;
sbit Bst				= Flag ^ 7;
sbit Blt				= Flag ^ 8;
sbit Data_Enable		= Flag ^ 9;

sbit KB_DATA	    		= P3^4;

unsigned char TX_Len				= 0;
unsigned char RX_Len				= 0;
unsigned char TX_Max_Len	 		= 0;
unsigned char RX_Max_Len			= 0;
unsigned char TX_Message_Pack_Len 	= 0;
unsigned char TX_Message_Unpack_Len 	= 0;
unsigned char RX_Message_Pack_Len 	= 0;
unsigned char RX_Message_Unpack_Len 	= 0;
unsigned char Sequence_Number		= 0;

extern LCD(unsigned char *,unsigned char) reentrant;
extern LCD_Back_Light(bit);

void Delay(unsigned int Temp_Delay) reentrant 
{
	unsigned char Ver;
	for(;Temp_Delay>0;Temp_Delay--);
	{
		for(Ver=0;Ver<100;Ver++);
	}
}

void UARTinit(void)
{
	SCON		= 0x50;
	RCAP2H	= 0xff;
	RCAP2L	= 0xfd;
	T2CON	= 0x34;
	T2MOD	= 0;
	ES		= 1;
}               
void Start_TX(void)
{
	TX_Enable = 1;
	TX_Len = 1;
	SBUF = TX_Buf[0];
}

void Phone_Init(void)
{
	unsigned char Ver=0;
	for(Ver = 0;Ver<=127;Ver++)
	{
		TX_Buf[Ver] = 0x55;
	}
	TX_Max_Len = 128;
	Start_TX();
	while(TX_Enable);
	Delay(10000);
}
void LCDinit(void)
{
	LCD("�",0x03); 
	LCD("�",0x20);
	LCD("�",0x28);
	LCD("�",0x0c);
	LCD("�",0x01);
	LCD("�",0x80);
}

void Wait_Msg()
{
	LCD("�",0x01);
	LCD("�",0x80);
	LCD(" Please Wait... ",0);
}

unsigned char SMSC_Pack(unsigned char xdata *Temp1,unsigned char xdata *Temp2)
{
	unsigned char High,Low,Ver1=0,Ver2;
	if(Temp2[Ver1]=='+')
	{
		Temp1[1] = 0x91;
		Ver1++;
	}
	else
		Temp1[1] = 0x91;
	Ver2=2;
	for(;Temp2[Ver1]!=0;)
	{
		Low = Temp2[Ver1]-'0';
		if(Temp2[Ver1+1]!=0)
		{
         High=Temp2[Ver1+1]-'0';
         Ver1=Ver1+2;
      }
      else
      {
        High=15;
        Ver1=Ver1+1;
      }   
      Temp1[Ver2]=High*16+Low;	          
      Ver2++; 
    }
  Temp1[0]=Ver2-1;
  return(Ver2);    
}
unsigned char Phone_Number_Pack(unsigned char xdata *Temp1,unsigned char xdata *Temp2)
{
	unsigned char High,Low,Ver1=0,Ver2;
	if(Temp2[Ver1]=='+')
	{
		Temp1[1] = 0x81;
		Ver1++;
	}
	else
	Temp1[1] = 0x81;
	Ver2=2;
	for(;Temp2[Ver1]!=0;)
	{
		Low = Temp2[Ver1] - '0';
		if(Temp2[Ver1+1]!=0)
		{
			High=Temp2[Ver1+1] - '0';
	          Ver1=Ver1+2;
    	}
	     else
    	{
	          High=15;
    	     Ver1=Ver1+1;
	     }   
    Temp1[Ver2]=High*16+Low;	          
    Ver2++; 
    }
  	Temp1[0]=10;
  	return(Ver2);    
} 

unsigned char Message_Pack(unsigned char xdata *Message)
{
	volatile unsigned char i=0,j=0,k=0,l1=0,l2=0;
	j=strlen(Message);
	k=j;
	i=0;
	while(Message[i])
	{
		Temp[j--] = Message[i++];
	}
	j=k;
	for(k=0;k<j;k++)
	{
		for(i=j;i>1;i--)
		{
			Bst=(Temp[i-1]	&	0x01);
			if(Bst)
			Temp[i]=Temp[i]	|	0x80;
		}
      l1++;
      if(l1>8)
      {
	     l1=0;
        	l2++;
      }
      j--; 
	   for(i=j;i>0;i--)
		{
			Temp[i]=Temp[i]>>1;
		}      
		if(j>k)
		k--;
	}
	j=strlen(Message);
	if((j%2)==0)
	l2--;
	if(l1!=0)
	l2++;
	l1=j-l2;
	Temp[l2]='\0';
	i=48;
	while(Temp[j])
	{
		 TX_Buf[i++] = Temp[j--];
	}
	return(l1);
}

unsigned char Packet_Sequence_Number()
{
 	Sequence_Number++;
 	Sequence_Number=Sequence_Number &	0x07;
 	return(Sequence_Number	|	0x40);
}

void Checksum()
{
	unsigned char Odd,Even,Temp;
	Odd	= TX_Buf[0];
	Even	= TX_Buf[1];
	for(Temp = 2;Temp<=TX_Max_Len-3;Temp=Temp+2)
	{
		Odd	= Odd ^ TX_Buf[Temp];
		Even	= Even ^ TX_Buf[Temp+1];
	}
	TX_Buf[TX_Max_Len-2] = Odd;
	TX_Buf[TX_Max_Len-1] = Even;
}


void Send_SMS(unsigned char *SMSC_Number,unsigned char *TX_Phone_Number ,unsigned char xdata *Message)
{
	xdata unsigned char Bcd[15];
	unsigned char Temp,Length;
	Phone_Init();
	Delay(10000);
	TX_Buf[0] = 0x1e;
	TX_Buf[1] = 0x00;
	TX_Buf[2] = 0x0c;
	TX_Buf[3] = 0x02;
	TX_Buf[4] = 0x00;
	TX_Buf[5] = 0x59;
	TX_Buf[6] = 0x00;
	TX_Buf[7] = 0x01;
	TX_Buf[8] = 0x00;
	TX_Buf[9] = 0x01;
	TX_Buf[10] = 0x02;
	TX_Buf[11] = 0x00;
	Length = SMSC_Pack(Bcd,SMSC_Number);
	for(Temp = 0;Temp<12;Temp++)
	{
		if(Temp<Length)
   			TX_Buf[Temp+12] = Bcd[Temp];
	 	else
   			TX_Buf[Temp+12] = 0;
	} 
	TX_Buf[24] = 0x15;
	TX_Buf[25] = 0x00;
	TX_Buf[26] = 0x00;
	TX_Buf[27] = 0x00;
	TX_Buf[28] = strlen(Message);
	TX_Message_Unpack_Len=TX_Buf[28];
	Length = Phone_Number_Pack(Bcd,TX_Phone_Number);
	for(Temp = 0;Temp<12;Temp++)
	{
		if(Temp<Length)
	   		TX_Buf[Temp+29] = Bcd[Temp];
	 	else
   			TX_Buf[Temp+29] = 0;
	}
	TX_Buf[41] = 0xa7;
	TX_Buf[42] = 0x00;
	TX_Buf[43] = 0x00;
	TX_Buf[44] = 0x00;
	TX_Buf[45] = 0x00;
	TX_Buf[46] = 0x00;
	TX_Buf[47] = 0x00;
	Length = Message_Pack(Message);
	TX_Message_Pack_Len=Length;
	TX_Buf[48+Length] = 0x01;
	TX_Buf[48+Length+1] = Packet_Sequence_Number();
	TX_Max_Len = 48+Length+1+1+2;
	Temp = 0;
	if(((Length+48+1)%2)==0)
	{
		TX_Max_Len++;
		TX_Buf[Length+48+2] = 0;
	   	Temp=1;
	}
	if(Temp==1)
  		TX_Buf[5] = TX_Max_Len-6-3;
	else
  		TX_Buf[5] = TX_Max_Len-6-2;
  	Checksum();
  	Start_TX();
  	while(TX_Enable);

}

void Serila_IRQ(void) interrupt 4
{
	if(RI==1)
	RI = 0;
	if(TI==1)
	{
		TI = 0;
 		if(TX_Len != TX_Max_Len && TX_Enable==1)
  		{
   			SBUF = TX_Buf[TX_Len++];
   		}
   		else
   		TX_Enable = 0;
	}
}

void main(void)
{
  	unsigned char t;
  	Delay(65530);
	LCDinit();
	LCD_Back_Light(0);
	UARTinit();
	EA = 1;
	Wait_Msg();
	for(t = 0;t<=5;t++)
  	{
  		Send_SMS(SMSC_Number,TX_Phone_Number,SMS_Message);
   	}
  	while(1);
}

