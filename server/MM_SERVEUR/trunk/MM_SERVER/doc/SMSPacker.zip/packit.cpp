//---------------------------------------------------------------------------
// Nokia Point-to-Point 7 Bit Message Packer
//
// Wayne Peacock
// (C) Embedtronics 2002-2004
// www.embedtronics.com
//
//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "packit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonPackClick(TObject *Sender)
{
String test;
char input[128];
char msg[128];
char decode[128];
int len;

test = Form1->Memo1->Lines->Text;
sprintf(input,"%s",test.c_str());
Edit1->Text = test.Length();

unsigned char c, w;
int n, shift, x;
len = strlen(input);
shift = 0; decode[0] = 0;

/* Decode into 7 bit characters */
for (n=0; n<len; ++n)
        {
        c = input[n] & 0x7f;
        c >>= shift;
        w = input[n+1] & 0x7f;
        w <<= (7-shift);
        shift +=1;
        c = c | w;
        if (shift == 7)
                {
                shift = 0x00;
                n++;
                }
        x = strlen(decode);
        decode[x] = c;
        decode[x+1] = 0;
        }

Edit2->Text = strlen(decode);

Memo2->Clear();
// Display decoded output as Hex
for (unsigned int i = 0; i < strlen(decode); i++)
  {
  sprintf(msg,"%.02X ",(unsigned char)decode[i]);
  Memo2->SetSelTextBuf(msg);
  }
}
//---------------------------------------------------------------------------
